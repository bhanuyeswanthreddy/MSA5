import { ComponentFixture, TestBed, async } from '@angular/core/testing';
import { HttpClientModule } from '@angular/common/http';
import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { EmployeeDetailsComponent } from './employee-details.component';
import { FormsModule } from '@angular/forms';
import { of } from 'rxjs';
import { EmployeeService } from '../employee.service';
import { Component, Directive } from '@angular/core';
import { Employee } from '../employee';



class MockEmployeeList { 
    getEmployeeById():Employee { 
    const dummyEmployee : Employee={
        id: 21,
        firstName: 'naveen',
        lastName: 'kumar',
        emailId: 'naveen452@gmail.com',
      }
      return dummyEmployee;
    }  
    
}

describe('EmployeeDetailsComponent', () => {
  let component: EmployeeDetailsComponent;
  let fixture: ComponentFixture<EmployeeDetailsComponent>;
  let employeeServiceComponent: EmployeeService;
  let serviceFixture: ComponentFixture<EmployeeService>;
  let spy:any;
  let service:EmployeeService;

//   const mockService=jasmine.createSpyObj("UserSvcService",["getEmployeeById"]);
  beforeEach(async(() => {
    TestBed.configureTestingModule({
        declarations: [ EmployeeDetailsComponent ],
        imports: [HttpClientTestingModule,
          HttpClientModule,
          RouterTestingModule,
          FormsModule],
      });
      fixture=TestBed.createComponent(EmployeeDetailsComponent);
      component=fixture.componentInstance;
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(EmployeeDetailsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('view employee details', () => {
    let employee = new MockEmployeeList();
    expect(employee.getEmployeeById().id).toEqual(21);
  });

  it('getEmployeeList is have been called', () => {
    let employee = new MockEmployeeList();
//     spy = spyOn(MockEmployeeList, getEmployeeList()).and.returnValue(true);
    expect(employee.getEmployeeById()).toHaveBeenCalled;
  });
});