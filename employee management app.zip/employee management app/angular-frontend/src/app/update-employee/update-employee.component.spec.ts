import { ComponentFixture, TestBed, async } from '@angular/core/testing';
import { FormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { UpdateEmployeeComponent } from './update-employee.component';
import { Employee } from '../employee';

class MockEmployee { 
    getEmployeeById():Employee { 
    const dummyEmployee : Employee={
        id: 21,
        firstName: 'naveen',
        lastName: 'kumar',
        emailId: 'naveen452@gmail.com',
      }
      return dummyEmployee;
    }
}

describe('UpdateEmployeeComponent', () => {
  let component: UpdateEmployeeComponent;
  let fixture: ComponentFixture<UpdateEmployeeComponent>;
  let updateEmployee: Employee;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ UpdateEmployeeComponent ],
      imports: [HttpClientTestingModule,
        HttpClientModule,
        RouterTestingModule,
        FormsModule]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(UpdateEmployeeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('Update employee details', () => {
    let employee = new MockEmployee();
    updateEmployee=employee.getEmployeeById();
    expect(employee.getEmployeeById().id).toEqual(21);
    updateEmployee.emailId='vbr1058@gmail.com';
    updateEmployee.firstName='Vinay';
    updateEmployee.lastName='B R';
    expect(updateEmployee.emailId).toEqual('vbr1058@gmail.com');
  });
});