import { Component, DebugElement } from '@angular/core';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { By } from '@angular/platform-browser';
import { async } from 'rxjs/internal/scheduler/async';
import { Employee } from '../employee';
import { FormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { CreateEmployeeComponent } from './create-employee.component';

describe('CreateEmployeeComponent', () => {
  let component: CreateEmployeeComponent;
  let fixture: ComponentFixture<CreateEmployeeComponent>;
  let fname: HTMLInputElement;
  let lname:  HTMLInputElement;
  let email:  HTMLInputElement;
  beforeEach((() => {
    
    TestBed.configureTestingModule({
      declarations: [ CreateEmployeeComponent ],
      imports: [HttpClientTestingModule,
        HttpClientModule,
        RouterTestingModule,
        FormsModule]
    });
    fixture=TestBed.createComponent(CreateEmployeeComponent);
    component=fixture.componentInstance;
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CreateEmployeeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });


  it('Setting value to input properties on form load', () => {
    const hostElement = fixture.nativeElement;
     fname= hostElement.querySelector('#firstName');
     lname = hostElement.querySelector('#lastName');
    email= hostElement.querySelector('#emailId');
    fixture.detectChanges();
    fname.value='Bhanu';
    lname.value='Yeswanth';
    email.value='Bhanu@gmail.com'; 
    
    fname.dispatchEvent(new Event('input'));
    lname.dispatchEvent(new Event('input'));
    email.dispatchEvent(new Event('input'));
    component.employee.firstName=fname.value;
    component.employee.lastName=lname.value;
    component.employee.emailId=email.value;
    expect(component.employee.firstName).toBe('Bhanu');
    expect(component.employee.lastName).toBe('Yeswanth');
    expect(component.employee.emailId).toBe('Bhanu@gmail.com');
  });
});