import { ComponentFixture, TestBed } from '@angular/core/testing';
import{async} from '@angular/core/testing'
import { FormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { EmployeeListComponent } from './employee-list.component';
import { Employee } from '../employee';


class MockEmployeeList { 
    getEmployeeList():Employee[] { 
    const dummyEmployee : Employee[]=[{
        id: 1,
        firstName: 'Bhanu',
        lastName: 'Yeswanth',
        emailId: 'bhanu@gmail.com',
      },{
        id: 2,
        firstName: 'manu',
        lastName: 'manu',
        emailId: 'manu@gmail.com',
      }];
      return dummyEmployee
    }  
}

describe('EmployeeListComponent', () => {
  let component: EmployeeListComponent;
  let fixture: ComponentFixture<EmployeeListComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ EmployeeListComponent ],
      imports: [HttpClientTestingModule,
        HttpClientModule,
        RouterTestingModule,
        FormsModule]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(EmployeeListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('list of all the employee', () => {
   let employeeList = new MockEmployeeList();
   expect(employeeList.getEmployeeList().length).toEqual(2);
  });
});